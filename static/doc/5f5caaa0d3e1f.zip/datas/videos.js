export default [
  {
    id: 1,
    title: '非常可爱的布偶插画制作流程',
    img_url: '/images/首页-推荐视频-01.png',
    viewcount: 5685
  },
  {
    id: 2,
    title: '让孩子爱上绘画的秘密',
    img_url: '/images/首页-推荐视频-02.png',
    viewcount: 3358
  },
  {
    id: 3,
    title: '快乐吃饭哦',
    img_url: '/images/首页-推荐视频-03.png',
    viewcount: 1122
  },
  {
    id: 4,
    title: '男孩女孩一起画',
    img_url: '/images/首页-推荐视频-04.png',
    viewcount: 2324
  }
]
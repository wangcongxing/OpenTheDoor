module.exports = [
  {
    id: 1001,
    title: '创意DIY班',
    subtitle: '适宜2~3岁的宝宝',
    img_url: '/images/课程封面-创意DIY班.png',
    color: '#4399F9',
    isFull: false
  },
  {
    id: 1002,
    title: '创意美术班',
    subtitle: '适合3~6岁儿童',
    img_url: '/images/课程封面-创意美术班.png',
    color: '#80c342',
    isFull: true
  },
  {
    id: 1003,
    title: '素描班',
    subtitle: '适合8岁以上的儿童',
    img_url: '/images/课程封面-素描班.png',
    color: '#ffc700',
    isFull: false
  },
  {
    id: 1004,
    title: '色彩班',
    subtitle: '适合6岁以上的儿童',
    img_url: '/images/课程封面-色彩班.png',
    color: '#F94388',
    isFull: false
  },
  {
    id: 1005,
    title: '速写班',
    subtitle: '适合6岁以上的儿童',
    img_url: '/images/课程封面-速写班.png',
    color: '#8C43F9',
    isFull: false
  }
]
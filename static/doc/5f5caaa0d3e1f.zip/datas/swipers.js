export default [
  {
    "id": 1,
    "img_url": "/images/首页banner-01.png"
  }, {
    "id": 2,
    "img_url": "/images/首页banner-02.png"
  }, {
    "id": 3,
    "img_url": "/images/首页banner-03.png"
  }
]
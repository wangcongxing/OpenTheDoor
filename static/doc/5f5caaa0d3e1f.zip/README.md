# wx-kudingyu
使用微信小程序开发的 项目（酷丁鱼商城网站）
档进行配置


首页
	swiper scroll-view
	view text image
	模版


课程
	view text image
	自定义组件的封装


我的
	自定义组件的封装
	事件交互
	全局数据共享
